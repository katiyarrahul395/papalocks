KEITHLOCKS AI — NETLIFY FIXED VERSION

1. Upload these files to the GitHub repository connected to your Netlify project:
   index.html
   netlify.toml
   package.json
   netlify/functions/chat.mjs

2. In Netlify open:
   Project configuration -> Environment variables

3. Add:
   Key: OPENAI_API_KEY
   Value: your OpenAI API key
   Scope: all deploy contexts

4. IMPORTANT: After saving the variable, trigger a NEW DEPLOY.
   Netlify environment-variable changes are not retroactive to an already deployed function.

5. Optional model variable:
   OPENAI_MODEL = gpt-5
   If your OpenAI account uses a different available model, change this value in Netlify.

6. Open your Netlify site and test “Good morning Keithlocks”.

This version keeps the API key on the Netlify server instead of exposing it in browser JavaScript.
